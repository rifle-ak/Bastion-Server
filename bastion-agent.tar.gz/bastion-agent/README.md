# Bastion Agent

A Claude-powered infrastructure management agent for Galaxy Gaming Host. Runs on a hardened bastion server and provides intelligent SSH-based access to downstream servers with structured audit logging, command allowlisting, and human approval gates for destructive operations.

## Quick Start

### Prerequisites

- Ubuntu 24.04 LTS (bastion server)
- Python 3.12+
- Anthropic API key

### Installation

```bash
# Clone the repo
git clone <repo-url> /opt/bastion-agent
cd /opt/bastion-agent

# Create venv and install
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"

# Set your API key
export ANTHROPIC_API_KEY="sk-ant-..."

# Run
bastion-agent
```

### Infrastructure Setup

1. **Harden the bastion server:**
   ```bash
   sudo bash scripts/setup-bastion.sh '<your-ssh-public-key>' 2222
   ```

2. **Generate SSH keys for downstream hosts:**
   ```bash
   sudo -u claude-agent bash scripts/generate-ssh-keys.sh gameserver-01 monitoring
   ```

3. **Prepare each downstream server:**
   ```bash
   sudo bash scripts/setup-downstream.sh <bastion-ip> '<agent-public-key>' game-server
   ```

4. **Configure the inventory** in `config/servers.yaml`

5. **Start the agent:**
   ```bash
   bastion-agent
   ```

## Architecture

See [CLAUDE.md](CLAUDE.md) for full technical specification.

## Security Model

- **Allowlist-based** — only explicitly permitted commands can run
- **Per-server SSH keys** — no shared keys across infrastructure
- **Human approval gate** — destructive operations require operator confirmation
- **Structured audit logging** — every tool call logged as JSON with full context
- **Input sanitization** — shell injection prevention via rejection (not escaping)
- **Scoped sudo** — downstream servers only allow specific commands via sudoers

## License

Proprietary — Galaxy Gaming Host LLC
