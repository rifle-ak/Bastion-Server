#!/usr/bin/env bash
# =============================================================================
# Galaxy Gaming Host — Downstream Server Preparation
# =============================================================================
# Run on each server that the bastion agent needs to access.
# Configures a locked-down user with scoped sudo and SSH access from bastion only.
#
# Usage: sudo bash setup-downstream.sh <BASTION_IP> <BASTION_PUBLIC_KEY> <ROLE>
#
# Arguments:
#   BASTION_IP          - IP address of the bastion server
#   BASTION_PUBLIC_KEY  - Public key string from bastion's agent user
#   ROLE                - Server role: "game-server" | "monitoring" | "generic"
# =============================================================================

set -euo pipefail

if [ $# -lt 3 ]; then
    echo "Usage: sudo bash $0 <BASTION_IP> <BASTION_PUBLIC_KEY> <ROLE>"
    echo "Roles: game-server, monitoring, generic"
    echo ""
    echo "Example:"
    echo "  sudo bash $0 10.0.0.5 'ssh-ed25519 AAAA... claude-agent@bastion' game-server"
    exit 1
fi

BASTION_IP="$1"
BASTION_KEY="$2"
ROLE="$3"
AGENT_USER="claude-agent"

echo "============================================"
echo "  Downstream Server Setup"
echo "  Bastion IP: ${BASTION_IP}"
echo "  Role: ${ROLE}"
echo "============================================"

# --- 1. Create Agent User ---
echo "[1/4] Creating agent user '${AGENT_USER}'..."
if ! id "${AGENT_USER}" &>/dev/null; then
    useradd -m -s /bin/bash "${AGENT_USER}"
    echo "  Created user ${AGENT_USER}"
else
    echo "  User ${AGENT_USER} already exists"
fi

# --- 2. Configure SSH Access (bastion only) ---
echo "[2/4] Configuring SSH access (bastion-only)..."
mkdir -p /home/${AGENT_USER}/.ssh
cat > /home/${AGENT_USER}/.ssh/authorized_keys << EOF
from="${BASTION_IP}",no-port-forwarding,no-X11-forwarding,no-agent-forwarding ${BASTION_KEY}
EOF
chmod 700 /home/${AGENT_USER}/.ssh
chmod 600 /home/${AGENT_USER}/.ssh/authorized_keys
chown -R ${AGENT_USER}:${AGENT_USER} /home/${AGENT_USER}/.ssh
echo "  SSH restricted to bastion IP ${BASTION_IP}"

# --- 3. Configure Scoped Sudo ---
echo "[3/4] Configuring scoped sudo for role '${ROLE}'..."

case "${ROLE}" in
    game-server)
        cat > /etc/sudoers.d/claude-agent << 'SUDOERS'
# Bastion agent — game server role
# Read-only operations
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/systemctl status *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/systemctl is-active *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/systemctl list-units *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/journalctl -u * --no-pager *

# Docker operations (read + restart with approval on agent side)
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/docker ps *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/docker logs *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/docker inspect *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/docker stats --no-stream
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/docker restart *

# Service management (restart gated by agent approval)
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/systemctl restart pterodactyl*
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/systemctl restart wings*
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/systemctl restart docker

# System info
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/df -h
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/free -h
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/uptime
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/ps aux
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/top -bn1
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/cat /var/log/*
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/tail *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/head *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/grep *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/find /var/log -name *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/ls -la *
SUDOERS
        ;;

    monitoring)
        cat > /etc/sudoers.d/claude-agent << 'SUDOERS'
# Bastion agent — monitoring role
# Read-only operations
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/systemctl status *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/systemctl is-active *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/journalctl -u * --no-pager *

# Docker / compose operations
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/docker ps *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/docker logs *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/docker inspect *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/docker stats --no-stream
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/docker compose -f /opt/monitoring/* *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/docker restart *

# System info
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/df -h
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/free -h
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/uptime
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/ps aux
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/cat /var/log/*
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/tail *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/head *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/ls -la *
SUDOERS
        ;;

    generic)
        cat > /etc/sudoers.d/claude-agent << 'SUDOERS'
# Bastion agent — generic role (minimal)
# Read-only operations only
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/systemctl status *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/systemctl is-active *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/journalctl -u * --no-pager *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/df -h
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/free -h
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/uptime
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/ps aux
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/cat /var/log/*
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/tail *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/head *
claude-agent ALL=(ALL) NOPASSWD: /usr/bin/ls -la *
SUDOERS
        ;;

    *)
        echo "ERROR: Unknown role '${ROLE}'. Use: game-server, monitoring, generic"
        exit 1
        ;;
esac

chmod 440 /etc/sudoers.d/claude-agent
visudo -c && echo "  Sudoers config valid" || { echo "  ERROR: Sudoers config invalid!"; exit 1; }
echo "  Sudo configured for role '${ROLE}'"

# --- 4. Restrict SSH to Bastion IP ---
echo "[4/4] Restricting SSH access to bastion IP..."

# Add UFW rule if UFW is active
if command -v ufw &>/dev/null && ufw status | grep -q "active"; then
    # Allow SSH from bastion only
    ufw allow from ${BASTION_IP} to any port 22 proto tcp comment "SSH from bastion"
    echo "  UFW rule added for bastion IP"
else
    echo "  UFW not active — add iptables rule manually:"
    echo "    iptables -A INPUT -p tcp --dport 22 -s ${BASTION_IP} -j ACCEPT"
    echo "    iptables -A INPUT -p tcp --dport 22 -j DROP"
fi

echo ""
echo "============================================"
echo "  Downstream Setup Complete"
echo "============================================"
echo ""
echo "This server now accepts SSH from ${BASTION_IP} as user '${AGENT_USER}'"
echo "with scoped sudo permissions for role '${ROLE}'."
echo ""
echo "Test from bastion:"
echo "  ssh ${AGENT_USER}@$(hostname -I | awk '{print $1}') 'sudo uptime'"
echo ""
