#!/usr/bin/env bash
# =============================================================================
# Galaxy Gaming Host — Bastion Server Hardening Script
# =============================================================================
# Run as root on a fresh Ubuntu 24.04 LTS minimal install.
# This script hardens the server for use as an SSH bastion / agent host.
#
# Usage: sudo bash setup-bastion.sh <YOUR_SSH_PUBLIC_KEY> [SSH_PORT]
#
# Arguments:
#   YOUR_SSH_PUBLIC_KEY  - Your personal SSH public key string (the whole line)
#   SSH_PORT             - Custom SSH port (default: 2222)
# =============================================================================

set -euo pipefail

# --- Arguments & Defaults ---
if [ $# -lt 1 ]; then
    echo "Usage: sudo bash $0 <YOUR_SSH_PUBLIC_KEY> [SSH_PORT]"
    echo "Example: sudo bash $0 'ssh-ed25519 AAAA... you@host' 2222"
    exit 1
fi

YOUR_SSH_KEY="$1"
SSH_PORT="${2:-2222}"
AGENT_USER="claude-agent"
ADMIN_USER="rifle"  # Change if your admin username differs

echo "============================================"
echo "  Bastion Server Hardening"
echo "  SSH Port: ${SSH_PORT}"
echo "  Agent User: ${AGENT_USER}"
echo "============================================"

# --- 1. System Updates ---
echo "[1/10] Updating system packages..."
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get upgrade -y -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
    ufw \
    fail2ban \
    auditd \
    audispd-plugins \
    unattended-upgrades \
    apt-listchanges \
    curl \
    wget \
    jq \
    python3 \
    python3-pip \
    python3-venv \
    git \
    rsync \
    htop \
    tmux

# --- 2. Create Admin User (if not exists) ---
echo "[2/10] Setting up admin user '${ADMIN_USER}'..."
if ! id "${ADMIN_USER}" &>/dev/null; then
    useradd -m -s /bin/bash -G sudo "${ADMIN_USER}"
    echo "  Created user ${ADMIN_USER}"
fi
mkdir -p /home/${ADMIN_USER}/.ssh
echo "${YOUR_SSH_KEY}" > /home/${ADMIN_USER}/.ssh/authorized_keys
chmod 700 /home/${ADMIN_USER}/.ssh
chmod 600 /home/${ADMIN_USER}/.ssh/authorized_keys
chown -R ${ADMIN_USER}:${ADMIN_USER} /home/${ADMIN_USER}/.ssh

# --- 3. Create Agent User ---
echo "[3/10] Creating agent user '${AGENT_USER}'..."
if ! id "${AGENT_USER}" &>/dev/null; then
    useradd -m -s /bin/bash "${AGENT_USER}"
    echo "  Created user ${AGENT_USER}"
fi
mkdir -p /home/${AGENT_USER}/.ssh/keys
chmod 700 /home/${AGENT_USER}/.ssh
chmod 700 /home/${AGENT_USER}/.ssh/keys
chown -R ${AGENT_USER}:${AGENT_USER} /home/${AGENT_USER}/.ssh

# --- 4. Harden SSH ---
echo "[4/10] Hardening SSH configuration..."
cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak

cat > /etc/ssh/sshd_config.d/99-bastion-hardening.conf << EOF
# Bastion hardening — $(date -u +%Y-%m-%dT%H:%M:%SZ)
Port ${SSH_PORT}
PermitRootLogin no
PasswordAuthentication no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
AuthorizedKeysFile .ssh/authorized_keys
X11Forwarding no
AllowTcpForwarding no
MaxAuthTries 3
MaxSessions 5
ClientAliveInterval 300
ClientAliveCountMax 2
LoginGraceTime 30

# Only allow specific users
AllowUsers ${ADMIN_USER} ${AGENT_USER}
EOF

# Validate sshd config before restarting
sshd -t && echo "  SSH config valid" || { echo "  ERROR: SSH config invalid!"; exit 1; }
systemctl restart sshd
echo "  SSH hardened on port ${SSH_PORT}"

# --- 5. Configure Firewall (UFW) ---
echo "[5/10] Configuring firewall..."
ufw --force reset
ufw default deny incoming
ufw default allow outgoing

# Allow SSH on custom port (restrict to your IPs in production!)
ufw allow ${SSH_PORT}/tcp comment "SSH bastion"

# Allow outbound to Anthropic API (HTTPS)
# UFW doesn't do outbound domain filtering well, but we allow 443 outbound
# For tighter control, use iptables or nftables with ipset for Anthropic's IPs

ufw --force enable
ufw status verbose
echo "  Firewall configured"

# --- 6. Configure Fail2Ban ---
echo "[6/10] Configuring Fail2Ban..."
cat > /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3
backend = systemd

[sshd]
enabled = true
port = ${SSH_PORT}
filter = sshd
maxretry = 3
bantime = 86400
EOF

systemctl enable fail2ban
systemctl restart fail2ban
echo "  Fail2Ban configured"

# --- 7. Configure Auditd ---
echo "[7/10] Configuring audit logging..."
cat > /etc/audit/rules.d/bastion.rules << 'EOF'
# Delete all existing rules
-D

# Buffer size
-b 8192

# Failure mode (1 = printk, 2 = panic)
-f 1

# Monitor all commands run by the agent user
-a always,exit -F arch=b64 -F euid=claude-agent -S execve -k agent_commands

# Monitor SSH key directory changes
-w /home/claude-agent/.ssh/ -p wa -k agent_ssh_keys

# Monitor config file changes
-w /etc/ssh/sshd_config -p wa -k sshd_config
-w /etc/ssh/sshd_config.d/ -p wa -k sshd_config

# Monitor user/group changes
-w /etc/passwd -p wa -k identity
-w /etc/group -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/sudoers -p wa -k sudoers
-w /etc/sudoers.d/ -p wa -k sudoers

# Make rules immutable (requires reboot to change)
-e 2
EOF

systemctl enable auditd
systemctl restart auditd
echo "  Audit logging configured"

# --- 8. Configure Unattended Upgrades ---
echo "[8/10] Configuring unattended security upgrades..."
cat > /etc/apt/apt.conf.d/20auto-upgrades << EOF
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
EOF

cat > /etc/apt/apt.conf.d/50unattended-upgrades << 'EOF'
Unattended-Upgrade::Allowed-Origins {
    "${distro_id}:${distro_codename}-security";
};
Unattended-Upgrade::Remove-Unused-Kernel-Packages "true";
Unattended-Upgrade::Remove-Unused-Dependencies "true";
Unattended-Upgrade::Automatic-Reboot "false";
EOF
echo "  Unattended upgrades configured"

# --- 9. Kernel Hardening (sysctl) ---
echo "[9/10] Applying kernel hardening..."
cat > /etc/sysctl.d/99-bastion-hardening.conf << 'EOF'
# IP Spoofing protection
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1

# Ignore ICMP broadcast requests
net.ipv4.icmp_echo_ignore_broadcasts = 1

# Disable source packet routing
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.default.accept_source_route = 0
net.ipv6.conf.all.accept_source_route = 0
net.ipv6.conf.default.accept_source_route = 0

# Ignore send redirects
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0

# Block SYN attacks
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_max_syn_backlog = 2048
net.ipv4.tcp_synack_retries = 2

# Log Martians
net.ipv4.conf.all.log_martians = 1

# Disable IPv6 if not needed (uncomment if you don't use IPv6)
# net.ipv6.conf.all.disable_ipv6 = 1
# net.ipv6.conf.default.disable_ipv6 = 1
EOF

sysctl -p /etc/sysctl.d/99-bastion-hardening.conf
echo "  Kernel hardening applied"

# --- 10. Setup Agent Working Directory ---
echo "[10/10] Preparing agent workspace..."
mkdir -p /opt/bastion-agent
mkdir -p /opt/bastion-agent/logs
mkdir -p /opt/bastion-agent/config
chown -R ${AGENT_USER}:${AGENT_USER} /opt/bastion-agent

echo ""
echo "============================================"
echo "  Bastion Hardening Complete"
echo "============================================"
echo ""
echo "Next steps:"
echo "  1. Test SSH access: ssh -p ${SSH_PORT} ${ADMIN_USER}@<bastion-ip>"
echo "  2. Generate SSH keys for downstream hosts:"
echo "     sudo -u ${AGENT_USER} bash scripts/generate-ssh-keys.sh"
echo "  3. Run setup-downstream.sh on each downstream server"
echo "  4. Deploy the bastion-agent application to /opt/bastion-agent/"
echo ""
echo "IMPORTANT: Add your IP(s) to UFW allow rules:"
echo "  ufw allow from <YOUR_IP> to any port ${SSH_PORT} proto tcp"
echo "  ufw delete allow ${SSH_PORT}/tcp  # Remove the open rule"
echo ""
