#!/usr/bin/env bash
# =============================================================================
# Galaxy Gaming Host — Generate SSH Keypairs for Downstream Servers
# =============================================================================
# Run as the claude-agent user on the bastion server.
# Generates a dedicated Ed25519 keypair per downstream server.
#
# Usage: bash generate-ssh-keys.sh <server-name> [server-name...]
#
# Example:
#   bash generate-ssh-keys.sh gameserver-01 gameserver-02 monitoring
#
# This generates:
#   ~/.ssh/keys/<server-name>_ed25519       (private key)
#   ~/.ssh/keys/<server-name>_ed25519.pub   (public key)
#   ~/.ssh/config entries for each server
# =============================================================================

set -euo pipefail

if [ $# -lt 1 ]; then
    echo "Usage: bash $0 <server-name> [server-name...]"
    echo "Example: bash $0 gameserver-01 monitoring"
    exit 1
fi

KEY_DIR="${HOME}/.ssh/keys"
SSH_CONFIG="${HOME}/.ssh/config"

mkdir -p "${KEY_DIR}"
chmod 700 "${KEY_DIR}"

# Ensure SSH config exists
touch "${SSH_CONFIG}"
chmod 600 "${SSH_CONFIG}"

echo "Generating SSH keypairs..."
echo ""

for SERVER in "$@"; do
    KEY_PATH="${KEY_DIR}/${SERVER}_ed25519"

    if [ -f "${KEY_PATH}" ]; then
        echo "  [SKIP] ${SERVER} — key already exists at ${KEY_PATH}"
        continue
    fi

    ssh-keygen -t ed25519 -N "" -C "claude-agent@bastion->${SERVER}" -f "${KEY_PATH}" -q
    chmod 600 "${KEY_PATH}"
    chmod 644 "${KEY_PATH}.pub"

    echo "  [OK] ${SERVER}"
    echo "        Private: ${KEY_PATH}"
    echo "        Public:  ${KEY_PATH}.pub"
    echo ""
    echo "        Public key to deploy on ${SERVER}:"
    echo "        $(cat ${KEY_PATH}.pub)"
    echo ""

    # Add SSH config entry if not already present
    if ! grep -q "^Host ${SERVER}$" "${SSH_CONFIG}" 2>/dev/null; then
        cat >> "${SSH_CONFIG}" << EOF

Host ${SERVER}
    HostName <REPLACE_WITH_IP>
    User claude-agent
    IdentityFile ${KEY_PATH}
    StrictHostKeyChecking yes
    IdentitiesOnly yes
    ConnectTimeout 10
    ServerAliveInterval 60
    ServerAliveCountMax 3
EOF
        echo "        Added SSH config entry (edit HostName in ${SSH_CONFIG})"
    fi

    echo "  ---"
done

echo ""
echo "Done. Next steps:"
echo "  1. Edit ${SSH_CONFIG} and set the correct HostName for each server"
echo "  2. Deploy public keys to each downstream server's authorized_keys"
echo "  3. Add host keys: ssh-keyscan -H <server-ip> >> ~/.ssh/known_hosts"
echo "  4. Test: ssh <server-name> 'uptime'"
